package Template_Method;

public class Turma2º extends ProfessorVirtual{
    public void aulaPortugues(){
        System.out.println("Estudar semanalmente Portugues por 6 horas");
        System.out.println("Apresentar o trabalho em grupo do conceito da semana passada");
    }
    
    public void aulaIngles(){
        System.out.println("Estudar semanalmente Historia por 4 horas");
        System.out.println("Finalizar o resumo do livro escolhido");
    }
}
    

