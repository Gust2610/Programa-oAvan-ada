package Template_Method;

public class Turma1º extends ProfessorVirtual {
    public void aulaMatematica(){
        System.out.println("Estudar semanalmente Matematica por 4 horas");
        System.out.println("Entregar os exercicios do capitulo 3");
    }
    
    public void aulaHistoria(){
        System.out.println("Estudar semanalmente Historia por 4 horas");
        System.out.println("Entregar os exercicios da pagina 8");
    }
}
