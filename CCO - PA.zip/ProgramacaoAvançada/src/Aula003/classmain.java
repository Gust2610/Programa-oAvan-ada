package Aula003;

public class classmain {
    private String nome;
    private int RA;

public classmain(String nome, int ra){
    this.nome=nome;
    this.RA=RA;
}
public String getNome(){
    return nome;
}
public int getRA(){
    return RA;
}
public int hashCode(){
    return (""+ nome + RA).hashCode();
}
public boolean equals(Object o){
    if(o == null){
        return false;
    }
if(!(o instanceof classmain)){
    return false;
}
classmain other = (classmain) o;
return this.getNome() == other.getNome() && this.hashCode() == other.hashCode();
}
}