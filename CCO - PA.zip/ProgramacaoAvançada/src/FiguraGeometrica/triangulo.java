package FiguraGeometrica;

public class triangulo {
    float base;
    float ladoB;
    float ladoC;
    float altura;
    public float setArea(){
        float area;
        area = (this.base*this.altura)/2;
        return area;
}
    public float setPerimetro(){
        float perimetro;
        perimetro = this.base+this.ladoB+this.ladoC;
        return perimetro;
}
}
    

