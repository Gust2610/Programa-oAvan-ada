package FiguraGeometrica;

public class calculoFigura {
    public static void main(String args[]){
        float resultadoA;
        float resultadoP;
        Quadrado quadrado = new Quadrado();
        quadrado.ladoA = 5;
        resultadoA = quadrado.setArea();
        resultadoP = quadrado.setPerimetro();
        System.out.println("A area da figura é de: \n"+resultadoA);
        System.out.println("O perimetro da figura é de:\n"+resultadoP);
  
        
        }
    }
    

