package FiguraGeometrica;

public class Retangulo {
    float ladoA;
    float ladoB;
    
    public float setArea(){
        float area;
        area = this.ladoA*this.ladoB;
        return area;
}
    public float setPerimetro(){
        float perimetro;
        perimetro = 2*this.ladoA+2*this.ladoB;
        return perimetro;
}
}