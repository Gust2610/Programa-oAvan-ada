package lavaRapido;

public class Veiculo {
    String tipoVeiculo;
    int codCliente;
    
}
