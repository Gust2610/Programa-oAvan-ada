package lavaRapido;

public class Cliente {
    String nome;
    int codCliente;
    int PosicaoFila;
    
}
