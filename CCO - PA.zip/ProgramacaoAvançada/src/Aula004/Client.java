package Aula004;
import java.util.ArrayList;
import java.util.List;

class Client {
  public static void main(String[] args) 
    {
        try {
          // Creating a component tree
          Component component = new CompositeArquivos("Root");
  
          // Adding all accounts of a customer to component
          component.add(new Arquivo("DA001", 100));
          component.add(new Arquivo("DA002", 150));

          // Creating a component tree
          Component subFolder = new CompositeArquivos("subFolder");
          component.add(subFolder);
  
          subFolder.add(new Arquivo("SA001", 200));
          subFolder.add(new Arquivo("SA002", 100));
          subFolder.add(new Arquivo("SA003", 300));
  
          // getting composite balance for the customer
          float totalSize = component.getSize();
          System.out.println("Total Size : " + totalSize);

          component.list();
        }
        catch (Exception e) {
          e.printStackTrace();
        }
    }
}