package Aula004;

public class Arquivo extends Component 
{
    private float size;
     
    public Arquivo(String name, float size) {
        super(name);
        this.size = size;
    }
 
    public float getSize() {
        return size;
    }
}